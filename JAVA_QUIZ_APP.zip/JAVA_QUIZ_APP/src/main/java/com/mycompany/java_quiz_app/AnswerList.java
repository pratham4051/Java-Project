package com.mycompany.java_quiz_app;

public class AnswerList {
}
